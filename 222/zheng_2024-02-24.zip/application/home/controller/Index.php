<?php
namespace app\home\controller;

use think\Facade\Config;
use think\Route;
use think\Db;
use think\Db\Where;
use think\Controller;

/*use com\neo4j\Graph;
use util\cmd\Console;
use Everyman\Neo4j\Client;*/

use GuzzleHttp\Client;

class Index extends Common {
	protected function initialize(){
		parent::initialize();
	}
	
    public function index(){
        $this->assign("date", date("Y-m-d"));
        return view();
    }
    
    
    /**
     * test guzzle
     * 2024-02-24
     */
    public function two(){

		$client = new GuzzleHttp\Client();
		$response = $client->request('GET', 'http://baidu.com');
		
		var_dump($response->getBody()->getContents());
    }
    
    
    /*public function testNeo4j(){
    	//require(getcwd() . '/../vendor/autoload.php');
    	
    	
    	
    	echo getcwd();
    	//exit;
    	
    	
    	
    	//$g= new Graph('http://user:pass@neo4j-db.example.com:7474/db/data');
    	//$g= new Graph('http://neo4j:genealogy@localhost:7474/gelealogy');
    	$g= new Graph('http://neo4j:neo4jneo4j@localhost:7474/neo4j');
    	$a= $g->open('MATCH (n) RETURN n');
    	dump($g);
    	foreach ($a as $record) {
		  Console::writeLine('#', $record['t.canonical'], ': ', $record['t.name']);
		}
    }
    
    
    public function neo4j2(){
    	$client = new Everyman\Neo4j\Client('localhost', 7474);
    	print_r($client->getServerInfo());
    }
    */
    
}
